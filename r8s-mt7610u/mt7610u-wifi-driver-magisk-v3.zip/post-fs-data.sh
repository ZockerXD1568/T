#!/system/bin/sh
# firmware_class path knob is absent on this kernel; firmware is served from /vendor/firmware
exit 0
