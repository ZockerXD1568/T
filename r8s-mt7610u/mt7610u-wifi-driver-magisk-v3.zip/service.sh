#!/system/bin/sh
# MT7610U all-in-one: load driver stack + firmware at boot
MODDIR=${0%/*}
LOG=/data/local/tmp/mt7610u-module.log
PATH=/system/bin:/system/xbin:/data/adb/magisk:$PATH
export PATH
{
echo "=== MT7610U WiFi module v3 boot log  $(date) ==="
# wait for filesystems, overlays and USB to settle
sleep 10

echo "--- firmware in place? ---"
for p in /vendor/firmware/mediatek/mt7610u.bin /vendor/etc/firmware/mediatek/mt7610u.bin; do
  [ -f "$p" ] && echo "FOUND $p" || echo "MISSING $p"
done

echo "--- loading driver stack (dependency order) ---"
for ko in ccm mac80211 mt76 mt76x0; do
  if lsmod | grep -q "^$ko "; then
    echo "$ko already loaded"
  else
    if insmod "$MODDIR/modules/$ko.ko" 2>/tmp/ins.err; then
      echo "insmod $ko OK"
    else
      echo "insmod $ko FAILED: $(cat /tmp/ins.err)"
    fi
  fi
done

echo "--- re-trigger adapter 0e8d:7610 so it (re)probes with driver+firmware ready ---"
FOUND=0
for dev in /sys/bus/usb/devices/*; do
  [ -f "$dev/idVendor" ] || continue
  if [ "$(cat $dev/idVendor 2>/dev/null)" = "0e8d" ] && [ "$(cat $dev/idProduct 2>/dev/null)" = "7610" ]; then
    FOUND=1
    echo 0 > "$dev/authorized" 2>/dev/null; sleep 2
    echo 1 > "$dev/authorized" 2>/dev/null; sleep 5
    echo "re-triggered $dev"
  fi
done
[ "$FOUND" = 0 ] && echo "adapter not on USB yet (plug it in, then Re-scan)"

echo "--- loaded modules ---"
lsmod | grep -E "mt76|mac80211|ccm|cfg80211"
echo "--- kernel log ---"
dmesg | grep -i -E "mt76|mt7610|mac80211|firmware" | tail -40
echo "--- interfaces ---"
ip link | grep -E "wlan|mon" || ip link
echo "=== end ==="
} > "$LOG" 2>&1
cp "$LOG" /sdcard/mt7610u-module.log 2>/dev/null
