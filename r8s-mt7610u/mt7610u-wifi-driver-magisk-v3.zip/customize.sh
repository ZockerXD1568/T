#!/system/bin/sh
ui_print "- MT7610U WiFi: driver + firmware (all-in-one)"
ui_print "- Kernel 4.19.325-cip126-st10-g88a015858b05"
ui_print "- Modules: ccm, mac80211, mt76, mt76x0"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm_recursive "$MODPATH/modules" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
ui_print "- Reboot, then plug the adapter (or Re-scan in Stryker)"
