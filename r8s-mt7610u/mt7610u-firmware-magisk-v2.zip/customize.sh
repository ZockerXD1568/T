#!/system/bin/sh
ui_print "- MT7610U firmware + boot-probe module v2"
ui_print "- Firmware -> /vendor/firmware, /vendor/etc/firmware, /system/etc/firmware"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
ui_print "- Reboot WITH the adapter plugged in"
ui_print "- Then read /sdcard/mt7610u-boot.log"
