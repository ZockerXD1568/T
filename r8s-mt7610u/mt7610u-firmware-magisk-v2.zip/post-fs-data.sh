#!/system/bin/sh
MODDIR=${0%/*}
KNOB=/sys/module/firmware_class/parameters/path
[ -e "$KNOB" ] && echo "$MODDIR/system/vendor/firmware" > "$KNOB" 2>/dev/null
exit 0
