#!/system/bin/sh
# MT7610U firmware boot probe + diagnostics
MODDIR=${0%/*}
LOG=/data/local/tmp/mt7610u-boot.log
PATH=/system/bin:/system/xbin:/data/adb/magisk:$PATH
export PATH

{
echo "=== MT7610U firmware module v2 boot log  $(date) ==="

# wait for USB + filesystems + overlays to settle
sleep 10

echo "--- firmware present in Android firmware dirs? ---"
for p in /vendor/firmware/mediatek/mt7610u.bin \
         /vendor/etc/firmware/mediatek/mt7610u.bin \
         /system/etc/firmware/mediatek/mt7610u.bin; do
  if [ -f "$p" ]; then echo "FOUND   $p ($(wc -c < "$p") bytes)"; else echo "MISSING $p"; fi
done

echo "--- looking for the adapter 0e8d:7610 on USB ---"
FOUND=0
for dev in /sys/bus/usb/devices/*; do
  [ -f "$dev/idVendor" ] || continue
  v=$(cat "$dev/idVendor" 2>/dev/null); p=$(cat "$dev/idProduct" 2>/dev/null)
  if [ "$v" = "0e8d" ] && [ "$p" = "7610" ]; then
    FOUND=1
    echo "adapter at $dev ($v:$p)"
    echo "--- re-triggering probe so the driver reloads firmware ---"
    echo 0 > "$dev/authorized" 2>/dev/null && echo "  de-authorized" || echo "  (could not de-authorize)"
    sleep 2
    echo 1 > "$dev/authorized" 2>/dev/null && echo "  re-authorized"  || echo "  (could not re-authorize)"
    sleep 6
  fi
done
[ "$FOUND" = 0 ] && echo "adapter NOT found on USB - is it plugged in and powered?"

echo "--- kernel log: firmware / mt76 ---"
dmesg | grep -i -E "mt76|mt7610|firmware" | tail -50

echo "--- network interfaces ---"
ip link 2>/dev/null || echo "(ip not available)"

echo "=== end of log ==="
} > "$LOG" 2>&1

# copy somewhere easy to open
cp "$LOG" /sdcard/mt7610u-boot.log 2>/dev/null
cp "$LOG" /storage/emulated/0/mt7610u-boot.log 2>/dev/null
