#!/system/bin/sh
ui_print "- MT7610U firmware module"
ui_print "- Chip 0e8d:7610 (MediaTek MT7610U)"
ui_print "- Firmware: mediatek/mt7610u.bin (80288 bytes)"
set_perm_recursive "$MODPATH/mediatek" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
ui_print "- After reboot: replug the adapter or Re-scan in Stryker"
