#!/system/bin/sh
MODDIR=${0%/*}
KNOB=/sys/module/firmware_class/parameters/path
[ -e "$KNOB" ] && echo "$MODDIR" > "$KNOB" 2>/dev/null
