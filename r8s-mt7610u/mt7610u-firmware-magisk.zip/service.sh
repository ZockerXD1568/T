#!/system/bin/sh
MODDIR=${0%/*}
KNOB=/sys/module/firmware_class/parameters/path
# wait for sysfs to be ready (up to ~30s), then set the path
i=0
while [ ! -e "$KNOB" ] && [ $i -lt 60 ]; do sleep 0.5; i=$((i+1)); done
if [ -e "$KNOB" ]; then
  echo "$MODDIR" > "$KNOB" 2>/dev/null
fi
# make sure the firmware is world-readable
chmod 0644 "$MODDIR/mediatek/mt7610u.bin" 2>/dev/null
